angular.module("cartapp")
	.directive("product", product);

function product() {
	return {
		restrict: "E",
		scope: {
			item: "=",
		},
		replace: true,
		templateUrl: "product/product.tpl.html",
		link: function(scope, element, attrs) {
			element.find("button").bind("click", function() {
				scope.$parent.updateHeroArea(scope.item);
			});
		}
	};
}