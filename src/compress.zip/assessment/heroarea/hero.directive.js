angular.module("cartapp")
	.directive("heroarea", heroarea);

function heroarea() {
	return {
		restrict: "E",
		scope: {
			item: "=",
		},
		replace: true,
		templateUrl: "heroarea/heroarea.tpl.html",
		link: function(scope, element, attrs) {
			element.find("button").bind("click", function() {
				//updateDetailBox(scope.item);
				alert(scope.item.pricing.price.selling);
			});
		}
	};
}